/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PratikumJava2021.PratikumTabel1;

import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author asus
 */

@Controller
public class ProjectController {
    @RequestMapping("/viewtabel")
    public String getData(Model Data){
        
        ArrayList<java.util.List<String>> data = new java.util.ArrayList<>();
        
        data.add(Arrays.asList("ID","Nomer KTP","Nama","Alamat"));
        data.add(Arrays.asList("122324","102938", "Rara","Yogyakarta"));
        data.add(Arrays.asList("122325","102939", "Denis","Yogyakarta"));
        data.add(Arrays.asList("122326","102940", "Saras","Yogyakarta"));
        data.add(Arrays.asList("122327","102940", "Dinda","Padang"));
        data.add(Arrays.asList("564389","128976", "Lisa","Jambi"));
        data.add(Arrays.asList("652092","028943", " Nisa","Batam"));
        data.add(Arrays.asList("986549","124876", "Fatika","Yogyakarta"));
        data.add(Arrays.asList("014502","560204", "Sasha","Yogyakarta"));
        data.add(Arrays.asList("875347","13287", "Arya","Aceh"));
        data.add(Arrays.asList("017356","345279", "Yoga","Solo"));
        data.add(Arrays.asList("014782","340278", "Bryan","Pati"));
        data.add(Arrays.asList("014234","340245","Rafi","Yogyakarta"));
        data.add(Arrays.asList("014289","323554", "Rini","Yogyakarta"));
        data.add(Arrays.asList("014078","340278", "Henri","Yogyakarta"));
        data.add(Arrays.asList("019432","340346", "Alan","Yogyakarta"));
        data.add(Arrays.asList("014932","340456", "Salsa","Bengkulu"));
        data.add(Arrays.asList("014056","340325", "Baron","Kalimantan"));
        data.add(Arrays.asList("0146343","343265", "Nada","Jambi"));
        data.add(Arrays.asList("0143452","359283", "Sekar","solo"));
        data.add(Arrays.asList("0143563","345462", "Icak","Medan"));
              
        
        Data.addAttribute("tabel", data);
        
        return "viewtabel";
    }
}
