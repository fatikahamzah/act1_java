package PratikumJava2021.PratikumTabel1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PratikumTabel1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
